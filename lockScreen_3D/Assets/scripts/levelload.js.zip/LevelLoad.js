﻿#pragma strict

function Start () {

}

function OnTriggerEnter () {
	Application.LoadLevel("2");
}